import{h_ as s,h$ as e}from"./productIcons-CHD_VPOe.js";const{sendMessage:a}=s({logger:e("UsageHistoryMessaging")});export{a as s};
