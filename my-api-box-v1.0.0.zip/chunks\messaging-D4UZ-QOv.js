import{h_ as s,h$ as e}from"./productIcons-CHD_VPOe.js";const i={Test:"taskNotifications:test"},{sendMessage:t}=s({logger:e("TaskNotificationMessaging")});export{i as T,t as s};
